import kartcal

kartcal.main()
